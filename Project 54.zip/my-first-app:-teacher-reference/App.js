import React, {Component} from 'react';
import {Button, View, Text} from 'react-native';

export default class App extends Component{
  displayAlert(){
    alert("I am an alert Box");
  }
  render() {
    return(
      <View style ={{ width:200,height :100,marginTop:50}}>
      <Button title ="Sound1" color ="red" onPress ={()=> Alert.alert('Play Sound 1')}/>
      <View style ={{ width:200,height :100,marginTop:70}}>
      <Button title ="Sound2" color ="blue" onPress ={()=> Alert.alert('Play Sound 1')}/>
      <View style ={{ width:200,height :100,marginTop:90}}>
      <Button title ="Sound3" color ="green" onPress ={()=> Alert.alert('Play Sound 1')}/>
     <View style ={{ width:200,height :100,marginTop:110}}>
      <Button title ="Sound4" color ="purple" onPress ={()=> Alert.alert('Play Sound 1')}/>

      </View>
      </View>
      </View>
      </View>
    );
  }
}